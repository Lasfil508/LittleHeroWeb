from src.Core import Core


if __name__ == '__main__':
    app = Core()
    app.mainLoop()
