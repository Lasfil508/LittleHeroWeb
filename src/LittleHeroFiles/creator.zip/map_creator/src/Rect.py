import pygame as pg


class Rect:
    def __init__(self, nomer):
        self.nomer = nomer
        self.is_stroke = False

    def draw(self, screen, x, y, size):
        if self.is_stroke:
            size -= 4
            x += 2
            y += 2
        if self.nomer == 1:
            screen.blit(pg.transform.scale(pg.image.load('src/img/sprites/dirt.jpg'), (size, size)), (x, y))
        elif self.nomer == 2:
            screen.blit(pg.transform.scale(pg.image.load('src/img/sprites/grass.jpg'), (size, size)), (x, y))
        elif self.nomer == 3:
            screen.blit(pg.transform.scale(pg.image.load('src/img/sprites/enemy.png'), (size, size)), (x, y))
        elif self.nomer == 4:
            screen.blit(pg.transform.scale(pg.image.load('src/img/sprites/lava.jpg'), (size, size)), (x, y))
        elif self.nomer == 5:
            screen.blit(pg.transform.scale(pg.image.load('src/img/sprites/door.png'), (size, size)), (x, y))
        elif self.nomer == 6:
            screen.blit(pg.transform.scale(pg.image.load('src/img/sprites/player_standing.png'), (size, size)), (x, y))
        else:
            pg.draw.rect(screen, pg.Color(255, 255, 255, 10), (x, y, size, size))
