import pygame as pg
from src.MenuManager import MenuManager
from src.const import *


class Core:
    def __init__(self):
        pg.init()

        self.WIDTH, self.HEIGHT = 600, 550
        self.run = True
        self.size = ()
        self.sc = pg.display.set_mode((self.WIDTH, self.HEIGHT))
        self.clock = pg.time.Clock()

        self.mm = MenuManager(self.WIDTH)

        self.keyR = False
        self.keyL = False
        self.keyU = False
        self.keySpace = False

        self.mouseEvent = None

        pg.display.set_caption('Little Hero!')
        pg.mouse.set_visible(False)

    def changeResolution(self, size):
        self.WIDTH, self.HEIGHT = size
        pg.display.set_mode(size, 0)

    def getInput(self):
        if self.mm.game_state == 'Game':
            for event in pg.event.get():
                if event.type == pg.QUIT:
                    self.run = False
                elif event.type == pg.KEYDOWN:
                    pass
                elif event.type == pg.KEYUP:
                    pass
                else:
                    self.mouseEvent = event

    def mainLoop(self):
        while self.run:
            self.sc.fill((0, 0, 0))
            self.getInput()
            self.mm.update(self)
            self.clock.tick(fps)
            pg.display.flip()

    def get_mm(self):
        return self.mm
