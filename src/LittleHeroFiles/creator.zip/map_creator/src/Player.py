import pygame as pg
from src.const import speed_increase_rate, jump_speed, jump_decrease_speed


class Player:
    def __init__(self, x_pos, y_pos):
        self.player_right = [
            pg.image.load('src/img/sprites/player_standing.png'),
            pg.image.load('src/img/sprites/player_run_1.png'),
            pg.image.load('src/img/sprites/player_run_2.png'),
            pg.image.load('src/img/sprites/ghost.png')
        ]
        self.image_index = 0
        self.image = self.player_right[self.image_index]
        self.rect = self.image.get_rect()
        self.rect.x = x_pos
        self.rect.y = y_pos
        self.width = self.image.get_width()
        self.height = self.image.get_height()
        self.x_vel = 0
        self.y_vel = 0
        self.direction = 0
        self.jump = False
        self.in_air = False
        self.is_die = False

    def death(self):
        self.x_vel = 0
        self.image_index = -1
        self.is_die = True

    def update(self, core, virtual_surface):
        if not self.is_die:
            self.player_physics(core)
        else:
            self.rect.y -= 1
        self.animate()
        self.draw(virtual_surface)

    def player_physics(self, core):
        if core.keyR and not self.jump:
            self.x_vel += speed_increase_rate
        elif core.keyL and not self.jump:
            self.x_vel -= speed_increase_rate
        if (core.keyU or core.keySpace) and not self.jump and not self.in_air:
            self.y_vel -= jump_speed
            self.jump = True

        if not core.keyR and not core.keyL and not self.jump:
            if self.x_vel < 0:
                self.x_vel += 1
            elif self.x_vel > 0:
                self.x_vel -= 1

        if self.x_vel < -10:
            self.x_vel = -10
        elif self.x_vel > 10:
            self.x_vel = 10

        self.rect.x += self.x_vel
        if self.jump:
            self.rect.y += self.y_vel
            self.y_vel += jump_decrease_speed
        if self.in_air:
            self.rect.y += 10

    def animate(self):
        if self.x_vel > 0:
            if self.image_index == 0 or self.image_index == 2:
                self.load_image(1)
            elif self.image_index == 1:
                self.load_image(2)
            self.direction = 1
        elif self.x_vel < 0:
            if self.image_index == 0 or self.image_index == 2:
                self.load_image(1, flip=True)
            elif self.image_index == 1:
                self.load_image(2, flip=True)
            self.direction = 0
        elif self.x_vel == 0:
            if self.image_index > 0:
                if self.direction == 0:
                    self.load_image(0, flip=True)
                elif self.direction == 1:
                    self.load_image(0)
            elif self.is_die:
                self.load_image(-1)

    def draw(self, virtual_surface):
        virtual_surface.blit(self.image, self.rect)

    def load_image(self, image_index, flip=False):
        self.image = pg.transform.flip(self.player_right[image_index], flip, False)
        self.image_index = image_index

    def setPos(self, x_pos, y_pos):
        self.rect.x = x_pos
        self.rect.y = y_pos
