import pygame as pg
from src.Button import Button
from src.Rect import Rect

from src.const import *


def map_to_string(tile_list):
    string = ''
    for i in range(20):
        for j in range(20):
            string += str(tile_list[i][j].nomer)
    return string


class Map:
    def __init__(self, WIDTH):
        self.tile_list = []
        for i in range(20):
            self.tile_list.append([])
            for j in range(20):
                self.tile_list[i].append(Rect(0))
        self.buttons = [Rect(i) for i in range(7)]
        self.buttons[0].is_stroke = True
        self.size = 1
        self.x = 1
        self.y = 1
        self.player_count = 0
        self.door_count = 0
        self.save = Button(0, 0, 27, 27, "Save", "src/img/menu/Button_1-1.png",
                           "src/img/menu/Button_1.png",
                           "src/sound/effects/click.mp3")
        self.exit = Button(0, 0, 27, 27, "Exit", "src/img/menu/Button_1-1.png",
                           "src/img/menu/Button_1.png",
                           "src/sound/effects/click.mp3")
        self.nomer = 0
        self.LMB = False
        self.pred_size = 0
        self.save = Button(0, 0, 27, 27, "Save", "src/img/menu/Button_1-1.png",
                           "src/img/menu/Button_1.png",
                           "src/sound/effects/click.mp3")
        self.exit = Button(0, 0, 27, 27, "Exit", "src/img/menu/Button_1-1.png",
                           "src/img/menu/Button_1.png",
                           "src/sound/effects/click.mp3")

    def draw(self, core):
        pg.mouse.set_visible(True)
        for i in range(20):
            for j in range(20):
                self.tile_list[i][j].draw(core.sc, self.x + self.size * j,
                                          self.y + self.size * i,
                                          self.size)
        for i in range(7):
            self.buttons[i].draw(core.sc, self.x + self.size * 20 + 9,
                                 self.y + self.size * i,
                                 self.size)
        self.save.draw(core.sc)
        self.exit.draw(core.sc)

    def update(self, core):
        if self.pred_size != core.sc.get_height() // 20:
            self.size = core.sc.get_height() // 20
            self.x = (core.sc.get_width() - (self.size * 20)) / 4
            self.y = (core.sc.get_height() - (self.size * 20)) / 2
            self.save = Button(self.x + self.size * 20 + 9,
                               self.y + self.size * 15,
                               self.size, self.size, "Save", "src/img/menu/Button_1-1.png",
                               "src/img/menu/Button_1.png",
                               "src/sound/effects/click.mp3")
            self.exit = Button(self.x + self.size * 20 + 9,
                               self.y + self.size * 17,
                               self.size, self.size, "Exit", "src/img/menu/Button_1-1.png",
                               "src/img/menu/Button_1.png",
                               "src/sound/effects/click.mp3")
        if core.mouseEvent:
            if core.mouseEvent.type == pg.MOUSEBUTTONDOWN and core.mouseEvent.button == 1:
                self.LMB = True
                pos = core.mouseEvent.pos
                if self.x + self.size * 20 + 9 <= pos[0] <= self.x + self.size * 21 + 9:
                    for i in range(7):
                        if self.y + self.size * i <= pos[1] < self.y + self.size * (i + 1):
                            self.nomer = i
                            self.buttons[i].is_stroke = True
                        else:
                            self.buttons[i].is_stroke = False
                pos = pos[0] - self.x, pos[1] - self.y
                flag = False
                for i in range(20):
                    for j in range(20):
                        if (self.size * i <= pos[1] <= self.size * (i + 1) and
                                self.size * j <= pos[0] <= self.size * (j + 1) and not flag):
                            if self.nomer == 6 and self.player_count == 0:
                                self.player_count += 1
                                self.tile_list[i][j].nomer = self.nomer
                            elif self.nomer == 5 and self.door_count == 0:
                                self.door_count += 1
                                self.tile_list[i][j].nomer = self.nomer
                            else:
                                if self.nomer != 5 and self.nomer != 6:
                                    if self.tile_list[i][j].nomer == 5:
                                        self.door_count -= 1
                                    elif self.tile_list[i][j].nomer == 6:
                                        self.player_count -= 1
                                    self.tile_list[i][j].nomer = self.nomer

            if core.mouseEvent.type == pg.MOUSEBUTTONUP and core.mouseEvent.button == 1:
                self.LMB = False
            if core.mouseEvent.type == pg.MOUSEMOTION:
                if self.LMB and not (self.nomer == 6 or self.nomer == 5):
                    pos = core.mouseEvent.pos
                    pos = pos[0] - self.x, pos[1] - self.y
                    for i in range(20):
                        for j in range(20):
                            if (self.size * i <= pos[1] <= self.size * (i + 1) and
                                    self.size * j <= pos[0] <= self.size * (j + 1)):
                                self.tile_list[i][j].nomer = self.nomer
            if core.mouseEvent:
                try:
                    self.save.handle_event(core.mouseEvent)
                    self.exit.handle_event(core.mouseEvent)
                    self.save.check_hover(core.mouseEvent.pos)
                    self.exit.check_hover(core.mouseEvent.pos)
                    if core.mouseEvent.type == pg.MOUSEBUTTONDOWN:
                        pos = core.mouseEvent.pos
                        if (self.x + self.size * 20 + 9 <= pos[0] <= self.x + self.size * 21 + 9
                                and self.y + self.size * 17 <= pos[1] <= self.y + self.size * 18):
                            core.get_mm().changeMenu()
                        if (self.x + self.size * 20 + 9 <= pos[0] <= self.x + self.size * 21 + 9
                                and self.y + self.size * 15 <= pos[1] <= self.y + self.size * 16):
                            print(map_to_string(self.tile_list))
                except Exception as e:
                    pass
        self.draw(core)
