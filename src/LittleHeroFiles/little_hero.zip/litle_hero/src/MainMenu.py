import pygame as pg
from src.Button import Button


class MainMenu:
    def __init__(self, WIDTH):
        pg.mixer.music.load("src/sound/menu/menu_sound.mp3")
        self.background_menu = pg.image.load(f"src/img/menu/back_menu{WIDTH}.jpg")
        self.cur = pg.image.load('src/img/menu/cursor.png')
        self.font = pg.font.Font(None, 72)

        self.button_1 = Button(WIDTH // 2 - (252 // 2), 250, 252, 74, "Начать", "src/img/menu/Button_1-1.png",
                               "src/img/menu/Button_1.png",
                               "src/sound/effects/click.mp3")
        self.button_2 = Button(WIDTH // 2 - (252 // 2), 350, 252, 74, "Настройки", "src/img/menu/Button_1-1.png",
                               "src/img/menu/Button_1.png", "src/sound/effects/click.mp3")
        self.button_3 = Button(WIDTH // 2 - (252 // 2), 450, 252, 74, "Выход", "src/img/menu/Button_1-1.png",
                               "src/img/menu/Button_1.png",
                               "src/sound/effects/click.mp3")

    def reloadBacground(self, WIDTH):
        self.background_menu = pg.image.load(f"src/img/menu/back_menu{WIDTH}.jpg")

    def playMusic(self):
        pg.mixer.music.play(-1, 7)

    def stopMusic(self):
        pg.mixer.music.stop()

    def update(self, core):
        self.getInput(core)
        self.draw(core)

    def getInput(self, core):
        for event in pg.event.get():
            if event.type == pg.QUIT:
                core.get_mm().stopGame(core)
                return 0

            if event.type == pg.USEREVENT and event.button == self.button_1:
                core.get_mm().newGame()
                return 0

            if event.type == pg.USEREVENT and event.button == self.button_2:
                core.get_mm().changeMenu()
                for btn in [self.button_1, self.button_2, self.button_3]:
                    btn.setPos(core.WIDTH // 2 - (252 // 2), btn.y)
                return 0

            if event.type == pg.USEREVENT and event.button == self.button_3:
                core.get_mm().stopGame(core)
                return 0

            for btn in [self.button_1, self.button_2, self.button_3]:
                btn.handle_event(event)

    def draw(self, core):
        core.sc.blit(self.background_menu, (0, 0))
        text_surface = self.font.render("Little Hero", True, (255, 0, 0))
        text_rect = text_surface.get_rect(center=(core.WIDTH // 2, 200))
        core.sc.blit(text_surface, text_rect)
        for btn in [self.button_1, self.button_2, self.button_3]:
            btn.check_hover(pg.mouse.get_pos())
            btn.draw(core.sc)
        x, y = pg.mouse.get_pos()
        core.sc.blit(self.cur, (x, y))
