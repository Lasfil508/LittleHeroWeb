import pygame as pg
from src.Button import Button
from src.const import *


class SettingsMenu:
    def __init__(self, WIDTH):
        self.background = pg.image.load(f"src/img/menu/back_settings{WIDTH}.jpg")
        self.cur = pg.image.load('src/img/menu/cursor.png')
        self.font = pg.font.Font(None, 72)
        self.resolution1 = Button(WIDTH // 2 - (252 // 2), 180, 252, 74, "600x550", "src/img/menu/Button_1-1.png",
                              "src/img/menu/Button_1.png",
                              "src/sound/effects/click.mp3")
        self.resolution2 = Button(WIDTH // 2 - (252 // 2), 280, 252, 74, "1024x650", "src/img/menu/Button_1-1.png",
                              "src/img/menu/Button_1.png",
                              "src/sound/effects/click.mp3")
        self.resolution3 = Button(WIDTH // 2 - (252 // 2), 380, 252, 74, "1366x768", "src/img/menu/Button_1-1.png",
                              "src/img/menu/Button_1.png",
                              "src/sound/effects/click.mp3")
        self.back = Button(WIDTH // 2 - (252 // 2), 480, 252, 74, "Назад", "src/img/menu/Button_1-1.png", "src/img/menu/Button_1.png",
                           "src/sound/effects/click.mp3")

    def reloadBacground(self, WIDTH):
        self.background = pg.image.load(f"src/img/menu/back_settings{WIDTH}.jpg")

    def update(self, core):
        self.getInput(core)
        self.draw(core)

    def getInput(self, core):
        for event in pg.event.get():
            if event.type == pg.QUIT:
                core.get_mm().stopGame()
                return 0

            if event.type == pg.USEREVENT and event.button == self.back:
                core.get_mm().changeMenu()
                return 0

            if event.type == pg.USEREVENT and event.button == self.resolution1:
                core.changeResolution((600, 550))
                self.reloadBacground(core.WIDTH)
                MainMenu = core.get_mm().getMainMenu()
                MainMenu.reloadBacground(core.WIDTH)
                for btn in [self.resolution1, self.resolution2, self.resolution3, self.back,
                            MainMenu.button_1, MainMenu.button_2, MainMenu.button_3]:
                    btn.setPos(core.WIDTH // 2 - 126, btn.y)
                return 0

            if event.type == pg.USEREVENT and event.button == self.resolution2:
                core.changeResolution((1024, 650))
                self.reloadBacground(core.WIDTH)
                MainMenu = core.get_mm().getMainMenu()
                MainMenu.reloadBacground(core.WIDTH)
                for btn in [self.resolution1, self.resolution2, self.resolution3, self.back,
                            MainMenu.button_1, MainMenu.button_2, MainMenu.button_3]:
                    btn.setPos(core.WIDTH // 2 - 126, btn.y)
                return 0

            if event.type == pg.USEREVENT and event.button == self.resolution3:
                core.changeResolution((1366, 768))
                self.reloadBacground(core.WIDTH)
                MainMenu = core.get_mm().getMainMenu()
                MainMenu.reloadBacground(core.WIDTH)
                for btn in [self.resolution1, self.resolution2, self.resolution3, self.back,
                            MainMenu.button_1, MainMenu.button_2, MainMenu.button_3]:
                    btn.setPos(core.WIDTH // 2 - 126, btn.y)
                return 0

            for btn in [self.resolution1, self.resolution2, self.resolution3, self.back]:
                btn.handle_event(event)

    def draw(self, core):
        core.sc.blit(self.background, (0, 0))
        text_surface = self.font.render("SETTINGS", True, (0, 0, 255))
        text_rect = text_surface.get_rect(center=(core.WIDTH // 2, 130))
        core.sc.blit(text_surface, text_rect)
        for btn in [self.resolution1, self.resolution2, self.resolution3, self.back]:
            btn.check_hover(pg.mouse.get_pos())
            btn.draw(core.sc)
        x, y = pg.mouse.get_pos()
        core.sc.blit(self.cur, (x, y))

