import pygame as pg
from src.Player import Player
from src.Button import Button
from src.Enemy import Enemy
from src.Door import Door
from src.Lava import Lava
from src.const import *


class Map:
    def __init__(self, WIDTH):
        self.tile_list = []
        self.level_index = 0
        self.dirt_img = pg.image.load('src/img/sprites/dirt.jpg')
        self.grass_img = pg.image.load('src/img/sprites/grass.jpg')
        self.bg_img = pg.image.load('src/img/sprites/sky.jpg')
        self.cur = pg.image.load('src/img/menu/cursor.png')
        pg.mixer.music.load("src/sound/game/game_sound.mp3")

        self.enemy_group = pg.sprite.Group()
        self.lava_group = pg.sprite.Group()
        self.door_group = pg.sprite.Group()

        self.virtual_surface = pg.Surface((1000, 1000))
        self.f1 = pg.font.Font(None, 36)

        self.player = Player(0, 0)

        self.restart_button = Button(374, 400, 252, 74, "Заново", "src/img/menu/Button_1-1.png",
                                     "src/img/menu/Button_1.png", "src/sound/effects/click.mp3")
        self.exit_button = Button(374, 500, 252, 74, "Выход", "src/img/menu/Button_1-1.png",
                                  "src/img/menu/Button_1.png",
                                  "src/sound/effects/click.mp3")

        self.vel_y = 0

    def load_level(self, level_index):

        self.enemy_group = pg.sprite.Group()
        self.lava_group = pg.sprite.Group()
        self.door_group = pg.sprite.Group()

        row_count = 0
        for row in levels[level_index]:
            col_count = 0
            for tile in row:
                if tile == 1:
                    img = pg.transform.scale(self.dirt_img, (tile_size, tile_size))
                    img_rect = img.get_rect()
                    img_rect.x = col_count * tile_size
                    img_rect.y = row_count * tile_size
                    tile = (img, img_rect)
                    self.tile_list.append(tile)
                if tile == 2:
                    img = pg.transform.scale(self.grass_img, (tile_size, tile_size))
                    img_rect = img.get_rect()
                    img_rect.x = col_count * tile_size
                    img_rect.y = row_count * tile_size
                    tile = (img, img_rect)
                    self.tile_list.append(tile)
                if tile == 3:
                    enemy = Enemy(col_count * tile_size, row_count * tile_size - 3)
                    self.enemy_group.add(enemy)
                if tile == 4:
                    lava = Lava(col_count * tile_size, row_count * tile_size)
                    self.lava_group.add(lava)
                if tile == 5:
                    door = Door(col_count * tile_size - 9, row_count * tile_size - 38)
                    self.door_group.add(door)
                if tile == 6:
                    self.player.setPos(col_count * tile_size, row_count * tile_size)
                    self.player.image_index = 0
                    self.player.image = pg.image.load('src/img/sprites/player_standing.png')
                    self.player.is_die = False
                col_count += 1
            row_count += 1

    def update(self, core):
        self.collision(core)
        if self.player.image_index == -1:
            self.menu(core)
        self.draw(core)
        for enemy in self.enemy_group:
            enemy.update()
        self.get_player().update(core, self.virtual_surface)

    def menu(self, core):
        if core.mouseEvent.type == pg.USEREVENT and core.mouseEvent.button == self.exit_button:
            core.get_mm().changeMenu()
            return 0

        if core.mouseEvent.type == pg.USEREVENT and core.mouseEvent.button == self.restart_button:
            self.load_level(self.level_index)
            return 0

        for btn in [self.exit_button, self.restart_button]:
            btn.handle_event(core.mouseEvent)

    def collision(self, core):
        for enemy in self.enemy_group:
            if enemy.rect.colliderect(self.get_player().rect.x, self.get_player().rect.y,
                                      self.get_player().width, self.get_player().height):

                if enemy.rect.x < self.get_player().rect.x and enemy.rect.y + 3 == self.get_player().rect.y:
                    self.player.x_vel = 0
                    self.player.rect.x -= 10
                    self.player.rect.y -= 9
                    self.player.image_index = -1
                elif enemy.rect.x > self.get_player().rect.x and enemy.rect.y + 3 == self.get_player().rect.y:
                    self.player.x_vel = 0
                    self.player.rect.x += 10
                    self.player.rect.y -= 9
                    self.player.image_index = -1
                elif enemy.rect.y + 3 > self.get_player().rect.y and self.player.image_index != -1:
                    enemy.kill()
            for tile in self.tile_list:
                if tile[1].colliderect(enemy.rect.x, enemy.rect.y,
                                       tile_size, tile_size):

                    if tile[1].x > enemy.rect.x and tile[1].y == enemy.rect.y + 3:
                        enemy.x_vel *= -1
                        enemy.rect.x = tile[1].x - tile_size
                        enemy.image = pg.image.load('src/img/sprites/enemy.png')
                    elif tile[1].x < enemy.rect.x and tile[1].y == enemy.rect.y + 3:
                        enemy.x_vel *= -1
                        enemy.rect.x = tile[1].x + tile_size
                        enemy.image = pg.transform.flip(pg.image.load('src/img/sprites/enemy.png'), True, False)
        count = 0
        if self.player.is_die:
            return 0
        if self.player.rect.x < 0:
            self.player.rect.x = 0
        elif self.player.rect.x > 1000:
            self.player.rect.x = 950
        if self.player.rect.y < 0:
            self.player.rect.y = 0
        elif self.player.rect.y > 1000:
            self.player.rect.y = 950
        for door in self.door_group:
            if door.rect.colliderect(self.get_player().rect.x, self.get_player().rect.y,
                                     self.get_player().width, self.get_player().height):
                self.level_index += 1
                self.load_level(self.level_index + 1)
        for tile in self.tile_list:
            if tile[1].colliderect(self.get_player().rect.x, self.get_player().rect.y,
                                   self.get_player().width, self.get_player().height):

                if tile[1].x > self.get_player().rect.x and tile[1].y == self.get_player().rect.y:
                    self.player.x_vel = 0
                    self.player.rect.x = tile[1].x - tile_size
                elif tile[1].x < self.get_player().rect.x and tile[1].y == self.get_player().rect.y:
                    self.player.x_vel = 0
                    self.player.rect.x = tile[1].x + tile_size
                if tile[1].y > self.get_player().rect.y:
                    self.player.y_vel = 0
                    self.player.rect.y = tile[1].y - tile_size
                    self.player.jump = False
                    self.player.in_air = False
                    count += 1
                elif tile[1].y < self.get_player().rect.y:
                    self.player.y_vel = 0
                    self.player.rect.y = tile[1].y + tile_size
        for lava in self.lava_group:
            if lava.rect.colliderect(self.get_player().rect.x, self.get_player().rect.y,
                                     self.get_player().width, self.get_player().height):
                count += 1
            if (lava.rect.x + 35 <= self.player.rect.x + tile_size <= lava.rect.x + tile_size + 20
                    and self.player.rect.y + 50 == lava.rect.y):
                self.player.death()

        if count == 0 and not self.player.jump:
            self.player.in_air = True

    def draw(self, core):
        self.virtual_surface.blit(self.bg_img, (0, 0))
        for tile in self.tile_list:
            self.virtual_surface.blit(tile[0], tile[1])
        self.enemy_group.draw(self.virtual_surface)
        self.lava_group.draw(self.virtual_surface)
        self.door_group.draw(self.virtual_surface)
        self.player.draw(self.virtual_surface)
        if self.player.image_index == -1:
            self.restart_button.check_hover(pg.mouse.get_pos())
            self.restart_button.draw(self.virtual_surface)
            self.exit_button.check_hover(pg.mouse.get_pos())
            self.exit_button.draw(self.virtual_surface)
            self.virtual_surface.blit(self.cur, pg.mouse.get_pos())
        scaled_surface = pg.transform.scale(self.virtual_surface, core.sc.get_size())
        core.sc.blit(scaled_surface, (0, 0))

    def get_player(self):
        return self.player
