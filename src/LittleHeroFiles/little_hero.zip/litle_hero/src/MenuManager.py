import pygame
from src.MainMenu import MainMenu
from src.SettingsMenu import SettingsMenu
from src.Map import Map


class MenuManager:
    def __init__(self, WIDTH):
        self.game_state = 'MainMenu'
        self.WIDTH = WIDTH
        self.main_menu = MainMenu(WIDTH)
        self.settings_menu = SettingsMenu(WIDTH)
        self.main_menu.playMusic()
        self.map = Map(WIDTH)

    def update(self, core):
        if self.game_state == 'MainMenu':
            self.main_menu.update(core)
        elif self.game_state == 'SettingsMenu':
            self.settings_menu.update(core)
        elif self.game_state == 'Game':
            self.map.update(core)

    def newGame(self):
        self.map.load_level(0)
        self.game_state = 'Game'

    def stopGame(self, core):
        core.run = False

    def changeMenu(self):
        if self.game_state == 'MainMenu':
            self.game_state = 'SettingsMenu'
        elif self.game_state == 'SettingsMenu':
            self.game_state = 'MainMenu'
        elif self.game_state == 'Game':
            self.game_state = 'MainMenu'

    def getMainMenu(self):
        return self.main_menu
