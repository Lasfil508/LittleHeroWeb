import pygame as pg


class Button:
    def __init__(self, x, y, width, height, text, image_path, hover_image_path=None, sound_path=None):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.text = text
        self.font = pg.font.Font(None, 36)

        self.image = pg.image.load(image_path)
        self.image = pg.transform.scale(self.image, (width, height))
        self.hover_image = self.image
        if hover_image_path:
            self.hover_image = pg.image.load(hover_image_path)
            self.hover_image = pg.transform.scale(self.hover_image, (width, height))
        self.rect = self.image.get_rect(topleft=(x, y))
        self.sound = None
        if sound_path:
            self.sound = pg.mixer.Sound(sound_path)
        self.is_hovered = False

    def setPos(self, x, y):
        self.x = x
        self.y = y
        self.rect = self.image.get_rect(topleft=(x, y))

    def draw(self, sc):
        if self.is_hovered:
            current_image = self.hover_image
        else:
            current_image = self.image
        sc.blit(current_image, self.rect.topleft)

        text_surface = self.font.render(self.text, True, (255, 255, 255))
        text_rect = text_surface.get_rect(center=self.rect.center)
        sc.blit(text_surface, text_rect)

    def check_hover(self, mouse_pos):
        self.is_hovered = self.rect.collidepoint(mouse_pos)

    def handle_event(self, event):
        if event.type == pg.MOUSEBUTTONDOWN and event.button == 1 and self.is_hovered:
            if self.sound:
                self.sound.play()
            pg.event.post(pg.event.Event(pg.USEREVENT, button=self))
